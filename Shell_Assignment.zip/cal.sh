#!/bin/bash
echo "Enter the value of a and b:"
read a
read b
echo "1.add"
echo "2.sub"
echo "3.multiply"
echo "4.divide"
echo "5.exit"

echo "Enter the choice"
read ch


case $ch in
	1)
		c= expr $a + $b
		echo "$c" ;;

	2)
		c= expr $a - $b
		echo "$c" ;;
	3)
		c= expr $a * $b
		echo "$c" ;;
	4)
		c= expr  $b/$a
		echo "$c" ;;
	*)
		echo "Wrong choice";;

esac

Enter the value of a and b:
12
15
1.add
2.sub
3.multiply
4.divide
5.exit
Enter the choice
1
27


